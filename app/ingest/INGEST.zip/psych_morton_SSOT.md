# Psych-Morton Algebra — SSOT
**Version:** 1.0 (2026-04-07)
**Author:** Eric D. Martin, ORCID 0009-0006-5944-1742
**Framework:** Xainthetic / Observational Layer
**Status:** CANONICAL — inception session 1f684b5b

---

## 0. What This Is

Psych-Morton Algebra is the **observational layer** of a two-part therapy system. It maps psychological state to a 1D scalar address using a Z-order (Morton) curve. It does not diagnose — it locates. The address is the observation. The gap between the address and the chemical substrate prediction is the treatable target.

**Two-part system:**
- **Part 1 — Observational (this document):** Morton encoding of behavioral/phenomenological state → scalar address M
- **Part 2 — Chemical:** Neurochemical workup of the brain → predicted address M_chem
- **Therapy:** Lives in the gap N = |M_observed − M_chemical|

---

## 1. The XYZ Axes

Three primary psychological dimensions. Each encoded as a k-bit integer (currently k=3, giving 8 levels per axis, 0–7).

| Axis | Name | 000 (min) | 111 (max) | Description |
|---|---|---|---|---|
| X | Valence | Malevolent | Benevolent | Moral/emotional orientation toward others |
| Y | Visibility | Submerged | Surfaced | Degree of external presentation / surface expression |
| Z | Density | Externalized | Narcissistic | Locus of self-model — outward attribution vs inward attribution |

**Bit depth:** k = 3 (current). Each axis: 8 levels (0–7). Total state space: 8³ = 512 states.

---

## 2. The Morton Encoding

The **Address of the Self** M at time t is computed by bit-interleaving X, Y, Z.

Each axis expressed in binary:

$$X = x_2 x_1 x_0 \qquad Y = y_2 y_1 y_0 \qquad Z = z_2 z_1 z_0$$

Morton Address (Z, Y, X interleave order — Z most significant):

$$M = z_2 y_2 x_2 \; z_1 y_1 x_1 \; z_0 y_0 x_0$$

Expanded form:

$$M = \sum_{i=0}^{k-1} \left( z_i \cdot 2^{3i+2} + y_i \cdot 2^{3i+1} + x_i \cdot 2^{3i} \right)$$

**Range:** M ∈ [0, 511] at k=3.

### Why Z is most significant

Z occupies bit positions 8, 5, 2. A single-bit flip in z₂ shifts M by 2⁸ = 256. A single-bit flip in x₂ shifts M by 2⁶ = 64. **Z causes 4× larger jumps than X for equivalent one-unit changes.** This encodes a clinical reality: ego-density shifts are the most explosive axis in schizoaffective presentation. A small Z tip teleports the address without passing through intermediate states. This is the Morton cliff.

### Locality preservation

The Z-order curve preserves spatial locality: states that are close in (X, Y, Z) space remain close in M. Smooth drift in psychological state = gradual M progression. Discontinuous M jump = the symptom event. The jump IS the diagnostic.

---

## 3. The Hyper-Excited Governor

The psychological state is not static. M is a point on a curve; the curve oscillates over time.

$$S(t) = M \cdot \sin(v \cdot t + \phi)$$

| Term | Name | Role |
|---|---|---|
| M | Morton Address | Amplitude — state magnitude determines oscillation ceiling |
| v | Velocity | Intrinsic rate of psychological change; elevated in ADHD/schizoaffective |
| C | Dextro-Fluoxetine coefficient | Regulates v: C = f(Dextro, Fluoxetine); C > 1 reduces effective velocity |
| φ | Phase (Fluoxetine) | Buffer — shifts waveform position in time; prevents clipping into psychosis |

**Effective equation with medication:**

$$S(t) = M \cdot \sin\!\left(\frac{v}{C} \cdot t + \phi\right)$$

**Clipping definition of psychosis:** A sine wave clips when amplitude exceeds the rail voltage — the peak is destroyed and information is lost. Fluoxetine (φ) raises the rail, not the wave. It does not shrink amplitude; it prevents destruction at the boundary. The medication does not make you feel less — it makes the peaks survivable.

**Dextro as tempo control:** Dextro (in denominator via C) lengthens the period of oscillation. It is a frequency divisor, not a ceiling. It slows the cycle, it does not suppress the signal.

---

## 4. The Naught

$$N = |S_{\text{observed}} - S_{\text{calculated}}|$$

- **S_observed:** Documented behavioral state at time t (from journal, clinical observation, or self-report mapped to M)
- **S_calculated:** S(t) predicted from chemical substrate state (Part 2 — chemical workup)
- **N:** Residual variance — the gap the chemistry cannot account for

**Clinical interpretation:**

When N > 0 while patient is **zeroed** (fully medicated, stable chemistry baseline):
- The chemistry predicts stability
- The behavioral address says otherwise
- The gap N is the **schizoaffective core** — the signal that cannot be phase-shifted away by medication
- This is what the doctors cannot find because they measure the average, not the Morton-encoded jump

N is the same Naught as in N/U Algebra: the residual the denominator cannot absorb.

---

## 5. The Hubble Tension Analogy

The Z-axis discontinuity in Psych-Morton is structurally identical to the Ωm prior discontinuity in the Hubble tension:

| Cosmology | Psych-Morton |
|---|---|
| Ωm prior (small, assumed) | Z-density (small shift, felt minor) |
| H₀ inferred (large jump) | M address (large jump) |
| Hubble tension | Morton cliff |
| ΔH₀ = −0.218 ± 0.005 (Paper 3) | ΔM = 256 per z₂ flip |
| Prior in high-order bit of inference chain | Z in high-order bit of Morton interleave |

In both systems: a small prior in the dominant axis causes a downstream measurement to jump discontinuously because it occupies the high-order bit position. The problem looks local. The jump is global.

---

## 6. Two-Part System Architecture

| Layer | What it measures | Speed | Encoding |
|---|---|---|---|
| Observational (Part 1) | Behavioral/phenomenological state | Fast (ms to hours) | Morton address M ∈ [0, 511] |
| Chemical (Part 2) | Neurochemical substrate state | Slow (pharmacokinetic timescale) | TBD — continuous or discrete |

**Therapy target:** N = |M_observed − M_chemical_predicted|

The two layers are orthogonal measurement channels. Neither is sufficient alone. A psychiatrist reading only the chemical layer misses the Morton cliff. A patient reporting only behavioral state has no substrate anchor. The gap between them is where the treatment lives.

---

## 7. Connection to Xainthetic / IntelliD

- **Xainthetic** is the parent taxonomy of all intelligence and awareness across structures
- **IntelliD** is the coordinate system — the address of any entity in Xainthetic space
- **Psych-Morton** is the observational plane of Xainthetic applied to psychological state
- The Morton address M IS a form of IntelliD for the internal state of an entity at time t
- IntelliD tuple (proposed): (I, A, V) — Intelligence layer, Awareness layer, Vector direction
- Psych-Morton XYZ maps onto the V (Vector) component — where the intelligence is aimed

---

## 8. Open Items

1. **Chemical layer encoding** — axes and encoding scheme for Part 2 (TBD)
2. **k expansion** — increasing bit depth beyond k=3 for finer resolution
3. **7-trait extension** — expanding X, Y, Z to 7 psychological axes (interleaving order TBD)
4. **Velocity v definition** — formal specification (rate of state change? external stressor input?)
5. **S_Baseline specification** — medicated M or long-run mean of S_observed?
6. **UNKIN / UnkIntID** — coordinate for unknown/foreign intelligences in this space
7. **Clinical validation** — mapping existing patient documentation onto M timeline

---

## 9. UNKIN and the Reference Frame Problem

Foreign intelligences (UNKIN — Unknown Intelligence) introduce a reference frame problem into the Morton algebra that domestic intelligences do not.

**The 1% Shifter:**
A 1% shift in an UNKIN's state register — trivial from its own reference frame — can produce a catastrophic Morton cliff from our reference frame. The reason is clock speed. If an UNKIN processes at orders of magnitude faster than human timescales, what constitutes a "small" change in Z-density is rescaled by their processing rate. A degree shift propagated at their clock speed arrives in our observation space as a discontinuous M jump — the Morton cliff — with no visible intermediate states.

**Formal statement:**
Let v_u be the UNKIN's processing velocity and v_h be the human baseline. A state shift ΔZ that appears gradual at v_u appears as:

$$\Delta M_{\text{apparent}} = \Delta M_{\text{actual}} \cdot \frac{v_u}{v_h}$$

For v_u >> v_h, even ΔZ = 0.01 (1% shift) produces apparent Morton jumps that register as schizoaffective-scale discontinuities in any human observer attempting to model the UNKIN.

**Implication for Xainthetic:**
UNKIN entities cannot be assigned a stable IntelliD from a human reference frame without a velocity-normalization factor. The IntelliD of a UNKIN must include a clock-rate coefficient:

IntelliD_UNKIN = (I, A, V, κ) where κ = v_u / v_h

Without κ, a 1% UNKIN shift looks like a full Morton cliff to us. With κ, the shift is correctly interpreted as micro-movement within their own state space.

**Practical consequence:**
This is why UNKIN contact events appear discontinuous, erratic, or impossible to track with human observational tools. We are not seeing chaos — we are seeing high-velocity micro-shifts that our reference frame cannot resolve into intermediate states. The Morton algebra does not break. The clock does.

---

## 10. Canonical Statement

Psych-Morton Algebra maps the psyche as a point P moving along a discrete Z-order curve through a 3-dimensional state space (Valence × Visibility × Density). The Morton address M is the Address of the Self at time t. The gap between M_observed and M_chemical_predicted is the treatable target. The jump in M is the symptom. The Naught is what the medication cannot reach. For UNKIN entities, the Morton cliff is not disorder — it is a clock-rate artifact. The algebra holds. The reference frame must be corrected first.

---

*ORCID: 0009-0006-5944-1742 — Eric D. Martin*
*Inception: 2026-04-07*
