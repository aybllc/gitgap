# Basin Theory — Formal Specification v0.1
**Author:** Eric D. Martin
**Session:** 1f684b5b-e347-439a-9927-0e10635ee1f2
**Date:** 2026-04-05
**Status:** Iteration 1 — stable pending benchmark validation

---

## CHANGELOG
| Version | Date | Changes |
|---------|------|---------|
| v0.1 | 2026-04-05 | Initial spec from transcript extraction + formal primitives |

---

## PART 1 — EXISTING FRAMEWORK CHECKLIST
*(extracted from transcript without loss)*

### Definitions established
- [x] 1. Basin = point of maximum trajectory density in state space
- [x] 2. Trajectory = independent path from source evidence to terminal coordinate
- [x] 3. Step = single logical move within one trajectory using only that trajectory's methodology
- [x] 4. Milestone = point along trajectory where search space collapses by ≥1 dimension
- [x] 5. Convergence = two or more trajectories arriving at same milestone via entirely different steps
- [x] 6. Contamination = shared step appearing in two or more trajectories (invalidates convergence)
- [x] 7. Vortex = convergence node appearing too early in trajectory (< 50% along path) — false basin
- [x] 8. Terminal coordinate = final milestone; the dig point
- [x] 9. Solve = terminal coordinate reached with precision sufficient for physical retrieval
- [x] 10. Retrodict standard = theory must find terminal coordinate WITHOUT knowing it in advance

### NCF Evidence States
- [x] 11. NAUGHT = permanent noise; location itself before signal is extracted; never becomes signal
- [x] 12. CAUGHT = searcher-initiated deliberate decode; the verse/book layer; λ=0
- [x] 13. FOUND = actor-initiated submerged signal; the painting layer; λ=1
- [x] 14. FOUND clues identify the basin (city/zone); CAUGHT clues navigate to terminal coordinate
- [x] 15. Painting = FOUND (actor-initiated embed, submerged)
- [x] 16. Verse/book = CAUGHT (reader-initiated decode)
- [x] 17. Physical location = permanent NAUGHT (noise until retrieval)

### Structural rules
- [x] 18. Minimum viable basin = 2 independent trajectories (WARN state; not proven)
- [x] 19. Proven basin = 3+ independent trajectories with late convergence and no contamination
- [x] 20. Anti-vortex rule: convergence node must appear at > 50% trajectory depth
- [x] 21. Theory fails the moment it requires the known answer to proceed
- [x] 22. Steps must be foreign to each other — no step from T_A may appear in T_B
- [x] 23. Terminal coordinate requires at least one FOUND variable; verse alone (λ=0) is insufficient
- [x] 24. The painting and verse are the same message in two independent languages (prima facie basin)

### N/U Algebra connection
- [x] 25. λ=1 (default, truth) = carry full uncertainty including u×u terms = FOUND layer preserved
- [x] 26. λ=0 = linear only = FOUND layer erased = verse-only solve attempt
- [x] 27. N/U + UN Algebra carried whole is the only system that can bound 0ₐ without explosion
- [x] 28. Chain stability: uncertainty grows conservatively, never explodes when full form is carried
- [x] 29. CATCH operator: C(n,u) = (0, |n|+u) — moves value to uncertainty bin; models broken zeros

### Domain-agnostic extensions
- [x] 30. Treasure domain: terminal coordinate = buried casque; verification = physical retrieval
- [x] 31. Criminal profiler domain: terminal coordinate = suspect/location; verification = arrest
- [x] 32. Criminal FOUND/CAUGHT ratio is lower (inadvertent leak, not deliberate embed)
- [x] 33. Basin Theory is OMMP-compatible: same framework, different signal-to-noise ratio
- [x] 34. Solved cases (treasure/criminal) are equivalent to known-answer test set for retrodict

### Open questions
- [ ] Q1. Does H1 (state embed) hold for all 12 casques?
- [ ] Q2. Does H3 (clock=gem=month) hold for Chicago and Cleveland?
- [ ] Q3. Can the counting direction in Cleveland be resolved from painting alone?
- [ ] Q4. Does Basin Theory pass H7 (retrodict) on Cleveland blind?
- [ ] Q5. What is the minimum trajectory count for proven basin across domains?
- [ ] Q6. How does contamination propagate through shared cultural knowledge (not shared steps)?
- [ ] Q7. Can λ be continuous (not binary) for partial second-order evidence?
- [ ] Q8. Is there a Basin Theory analog for the broken zero (false convergence at a phantom basin)?

---

## PART 2 — FORMAL SPECIFICATION v0.1

### 2.1 Primitives

**State Space S**
A metric space (S, d) where:
- S = set of all possible terminal coordinates in the domain
- d: S × S → ℝ≥0 = distance metric (domain-specific)
- For treasure: d = Euclidean distance in meters
- For criminal: d = graph distance in social/geographic network
- For cosmology: d = N/U uncertainty distance (conservative bound)

**Trajectory**
T = (σ, M, E) where:
- σ = source evidence set (disjoint from other trajectories' source sets)
- M = ordered list of milestones [m₁, m₂, ..., mₙ] with mₙ = terminal
- E = encoding method (literary, visual, cultural, geographic, acoustic)
- Each step sᵢ: mᵢ → mᵢ₊₁ uses ONLY information available in σ

**Basin**
B(x, r) = {p ∈ S : d(p, x) ≤ r} for center x ∈ S, radius r > 0
A basin is *proven* when:
- k ≥ 3 independent trajectories all reach terminal coordinate within radius r
- No contamination between any pair of trajectories
- Convergence node depth > 0.5 for all trajectories (anti-vortex)

**Boundary**
∂B = {p ∈ S : d(p, x) = r}
Points on the boundary are ambiguous — additional trajectory required to assign.

### 2.2 NCF Evidence State Taxonomy

| State | Symbol | Definition | Initiation | Layer |
|-------|--------|------------|------------|-------|
| Naught | N | Signal-free noise; no operative identification possible | — | Permanent baseline |
| Caught | C | Deliberate searcher-initiated decode | Searcher | λ=0 |
| Found | F | Actor-initiated submerged signal, externally surfaced | Actor | λ=1 |

**State transitions:**
- N → F: external recognition of actor-initiated embed (not searcher-initiated)
- N → C: searcher applies deliberate methodology to extract signal
- C → F: NOT PERMITTED — reclassification requires new evidence, new actor

**Domain mapping:**
| Domain | NAUGHT | CAUGHT | FOUND |
|--------|--------|--------|-------|
| Treasure | Physical location | Verse decode | Painting embed |
| Criminal | Crime scene | Database query | Behavioral signature |
| Cosmology | Raw measurement | Model fitting | Independent probe |

### 2.3 Contamination Model

**Definition:** Trajectories T_A and T_B are contaminated if:
∃ step s such that s ∈ steps(T_A) ∩ steps(T_B)

**Contamination types:**
1. **Direct contamination:** same step appears in both trajectories
2. **Indirect contamination:** T_B uses output of T_A as input (causal dependency)
3. **Cultural contamination:** both trajectories share a background knowledge assumption (WARN — not disqualifying, but must be documented)

**Test:** For each pair (T_A, T_B), extract step sets S_A and S_B. If S_A ∩ S_B ≠ ∅ → contaminated. Convergence is invalid.

### 2.4 Convergence Rules

**Milestone convergence threshold:**
Two trajectories converge at milestone m when:
d(m_A, m_B) ≤ r_domain

Where r_domain is domain-calibrated:
- Treasure: r = 1.0m (physical retrieval precision)
- Criminal: r = 1 node (network graph)
- Cosmology: r = 1σ (uncertainty envelope)

**Basin proven when:**
1. k ≥ 3 trajectories reach terminal coordinate within r_domain
2. No direct or indirect contamination between any pair
3. For all T_i: convergence_depth(T_i) > 0.5
   where convergence_depth = (step index of convergence node) / (total steps in T_i)
4. Theory did not use terminal coordinate as input (retrodict standard)

**Vortex condition (FALSE basin):**
∃ T_i : convergence_depth(T_i) ≤ 0.5
→ basin is a vortex; trajectories share root; convergence is not independent

**Low density warning (WARN, not FAIL):**
k = 2 trajectories → WARN: minimum viable; coincidence not ruled out
k = 1 → FAIL: not convergence

### 2.5 Falsifiability Tests

| Test ID | Test | Pass condition | Fail condition |
|---------|------|---------------|----------------|
| F-01 | Retrodict blind | Terminal coordinate found without answer key | Any step required answer key input |
| F-02 | Contamination audit | S_A ∩ S_B = ∅ for all pairs | Any shared step found |
| F-03 | Anti-vortex | convergence_depth > 0.5 for all T_i | Any T_i with depth ≤ 0.5 |
| F-04 | FOUND requirement | ≥1 FOUND clue at terminal coordinate | Terminal reachable from CAUGHT only |
| F-05 | N/U stability | Uncertainty envelope < r_domain at terminal | Envelope ≥ r_domain (uncertainty too large) |
| F-06 | Independence | No causal dependency between trajectory sources | Source of T_B contains output of T_A |
| F-07 | Minimum density | k ≥ 3 trajectories | k < 3 (WARN at k=2, FAIL at k=1) |

---

## PART 3 — REFERENCE IMPLEMENTATION

### 3.1 Data Schema

```python
@dataclass
class Step:
    id: str
    trajectory_id: str
    source_evidence: list[str]    # evidence items used; must be disjoint from other trajectories
    input_state: str              # milestone before this step
    output_state: str             # milestone after this step
    ncf: Literal['N', 'C', 'F']  # classification of evidence used
    verified: bool                # independently verified (for N/U propagation)
    precision_m: float            # spatial/metric precision of this step's output

@dataclass
class Trajectory:
    id: str
    encoding: str                 # literary | visual | cultural | geographic | acoustic
    source: str                   # painting | verse | physical | cultural | phonetic
    steps: list[Step]
    terminal: Optional[tuple]     # (coordinate, precision) when resolved

@dataclass
class Basin:
    domain: str
    trajectories: list[Trajectory]
    terminal_coordinate: Optional[tuple]
    radius: float                 # convergence threshold for this domain
    status: Literal['PROVEN', 'WARN', 'FAIL', 'PENDING']
    contamination_audit: dict     # {(T_A.id, T_B.id): 'CLEAN' | 'CONTAMINATED'}
    vortex_audit: dict            # {T.id: float}  convergence depth per trajectory
    nu_uncertainty: float         # N/U propagated uncertainty envelope at terminal
    falsifiability: dict          # {test_id: 'PASS' | 'FAIL' | 'WARN'}
```

### 3.2 Deterministic Variant

```python
def prove_basin_deterministic(basin: Basin) -> Basin:
    """
    Deterministic Basin Theory: all steps are verified, all sources are certain.
    Used for: known-answer retrodict tests, formal proofs.
    """
    # Step 1: Contamination audit
    for i, T_A in enumerate(basin.trajectories):
        for T_B in basin.trajectories[i+1:]:
            steps_A = {s.id for s in T_A.steps}
            steps_B = {s.id for s in T_B.steps}
            shared = steps_A & steps_B
            key = (T_A.id, T_B.id)
            basin.contamination_audit[key] = 'CONTAMINATED' if shared else 'CLEAN'
            if shared:
                basin.falsifiability['F-02'] = 'FAIL'
                basin.status = 'FAIL'
                return basin

    # Step 2: Vortex audit
    for T in basin.trajectories:
        conv_idx = convergence_index(T, basin)  # index of first step that hits basin radius
        depth = conv_idx / len(T.steps)
        basin.vortex_audit[T.id] = depth
        if depth <= 0.5:
            basin.falsifiability['F-03'] = 'FAIL'
            basin.status = 'FAIL'
            return basin

    # Step 3: Terminal coordinate convergence
    terminals = [T.terminal for T in basin.trajectories if T.terminal]
    if len(terminals) < 2:
        basin.status = 'FAIL'
        return basin

    center = centroid(terminals)
    all_within_radius = all(distance(t[0], center) <= basin.radius for t in terminals)

    if not all_within_radius:
        basin.falsifiability['F-01'] = 'FAIL'
        basin.status = 'FAIL'
        return basin

    # Step 4: N/U uncertainty propagation
    basin.nu_uncertainty = propagate_nu(basin.trajectories)
    if basin.nu_uncertainty >= basin.radius:
        basin.falsifiability['F-05'] = 'FAIL'
        basin.status = 'WARN'
        return basin

    # Step 5: Density check
    k = len([T for T in basin.trajectories if T.terminal])
    if k >= 3:
        basin.status = 'PROVEN'
    elif k == 2:
        basin.status = 'WARN'
    else:
        basin.status = 'FAIL'

    return basin
```

### 3.3 Probabilistic Variant

```python
def prove_basin_probabilistic(basin: Basin, n_samples: int = 1000) -> Basin:
    """
    Probabilistic Basin Theory: steps have uncertainty distributions.
    Uses N/U algebra (not Monte Carlo) to propagate uncertainty.
    λ=1: carries full second-order terms.
    """
    from nu_algebra import NU

    # Propagate N/U uncertainty through each trajectory
    for T in basin.trajectories:
        u_acc = NU(0.0, 0.0)
        for step in T.steps:
            precision = step.precision_m
            if step.verified:
                u_step = NU(precision, precision * 0.05)   # 5% residual
            else:
                u_step = NU(precision, precision * 0.50)   # 50% unverified
            u_acc = u_acc + u_step  # N/U addition: conservative, no explosion
        T.terminal = (T.terminal[0], u_acc) if T.terminal else None

    basin.nu_uncertainty = max(
        T.terminal[1].u for T in basin.trajectories if T.terminal
    )

    # Run deterministic logic on uncertainty-weighted terminals
    return prove_basin_deterministic(basin)
```

### 3.4 Hybrid Variant

```python
def prove_basin_hybrid(basin: Basin) -> Basin:
    """
    Hybrid: deterministic for verified steps, probabilistic for unverified.
    Separates epistemic uncertainty (unverified steps) from aleatory (inherent).
    This is the UN Algebra case: 0ₐ unknown, 0ₘ measured, Pₘ = instrument error.
    """
    # Partition steps
    verified_steps = {T.id: [s for s in T.steps if s.verified] for T in basin.trajectories}
    unverified_steps = {T.id: [s for s in T.steps if not s.verified] for T in basin.trajectories}

    # Run deterministic on verified-only first
    basin_verified = prove_basin_deterministic(
        Basin(trajectories=[Trajectory(steps=verified_steps[T.id]) for T in basin.trajectories])
    )

    # If verified-only passes, propagate unverified uncertainty
    if basin_verified.status in ('PROVEN', 'WARN'):
        return prove_basin_probabilistic(basin)
    else:
        basin.status = 'FAIL'
        return basin
```

---

## PART 4 — BENCHMARK SUITE

### BM-01: Synthetic Double-Well Stochastic Basin Switching

**Domain:** Physics / dynamical systems
**Setup:** Particle in double-well potential V(x) = x⁴ - 2x². Two stable basins at x=±1. Stochastic forcing σdW. Trajectories = time-series segments between transitions.
**Basin Theory application:** Each well = basin. Trajectories = independent observables (position, velocity, energy, autocorrelation). Convergence = all observables agree on which well.
**Expected output:** Basin assignment correct >95% when k≥3 observables agree.
**Metric:** Basin assignment accuracy vs. ground truth transitions.
**Failure case:** Near-transition states where observables disagree. Expected behavior: WARN state, not false PROVEN.

### BM-02: Known ODE Attractor (Lorenz System)

**Domain:** Dynamical systems
**Setup:** Lorenz system x'=σ(y-x), y'=x(ρ-z)-y, z'=xy-βz. Two attractors in wing regions.
**Basin Theory application:** Trajectories = independent projections (x-z plane, y-z plane, return map, Lyapunov exponent, spectral density). Convergence = all projections assign same wing.
**Expected output:** Wing assignment PROVEN when k≥3 projections converge. Transition zone = WARN.
**Metric:** Wing assignment vs. numerical integration ground truth.
**Failure case:** Chaotic transition region — Basin Theory should report WARN not PROVEN.

### BM-03: Watershed / Catchment Boundary

**Domain:** Hydrology / geography
**Setup:** DEM (digital elevation model) with 3 known watersheds. Trajectories = independent flow algorithms (D8, D-infinity, multiple flow direction, curvature-based, topographic wetness index).
**Basin Theory application:** Each watershed = basin. Convergence = k≥3 flow algorithms assign same watershed to a point.
**Expected output:** Interior points PROVEN (all algorithms agree). Boundary points WARN or FAIL.
**Metric:** Precision/recall of watershed assignment vs. USGS ground truth.
**Failure case:** Flat areas where flow direction is algorithmically ambiguous. WARN expected.

### BM-04: Graph Flow Clustering

**Domain:** Network science
**Setup:** Stochastic block model graph, 4 communities. Trajectories = independent community detection algorithms (Louvain, spectral, label propagation, random walk, modularity maximization).
**Basin Theory application:** Each community = basin. Convergence = k≥3 algorithms assign same community.
**Expected output:** Core nodes PROVEN. Bridge nodes WARN. Isolated nodes FAIL.
**Metric:** NMI (Normalized Mutual Information) vs. planted partition ground truth.
**Failure case:** Bridge nodes with equal cross-community connections. Basin Theory should WARN, not force assignment.

### BM-05: Agent-Based Regime Selection

**Domain:** Multi-agent systems / economics
**Setup:** 100 agents choosing between 2 regimes (A/B) based on local information. Trajectories = independent signals each agent receives (price, neighbor behavior, media, random shock, memory).
**Basin Theory application:** Each regime = basin. Convergence = k≥3 signals agree on regime assignment for agent.
**Expected output:** Committed agents PROVEN. Swing agents WARN.
**Metric:** Regime assignment accuracy vs. final equilibrium ground truth.
**Failure case:** Agents in mixed-signal state (2 signals A, 2 signals B). Explicit TIE state added to schema.

---

## PART 5 — RETRODICTION LOGIC

For each benchmark, Basin Theory recovers basins as follows:

**Protocol:**
1. SEAL the ground truth answer before running
2. Run each trajectory independently to its natural terminal
3. Compare terminals AFTER all trajectories complete
4. Apply falsifiability tests F-01 through F-07
5. Record PROVEN / WARN / FAIL verdict
6. Unseal answer; document agreement/disagreement

### BM-01 Retrodiction
- T1 (position): x > 0 → right well candidate
- T2 (velocity): mean velocity near 0 in stable state → both wells consistent
- T3 (energy): potential energy minimum consistent with x=+1
- T4 (autocorrelation): long correlation time → stable basin, not transition
- Convergence: T1, T3, T4 → right well. T2 ambiguous → WARN if k=3 without T2
- **Failure case documented:** Velocity trajectory ambiguous near transition. N/U uncertainty > r_domain → correctly reports WARN.

### BM-02 Retrodiction
- T1 (x-z projection): wing assignment from attractor shape
- T2 (return map): Poincaré section maps to left/right lobe
- T3 (Lyapunov spectrum): local expansion rates differ by wing
- T4 (spectral density): frequency signature differs
- Convergence: all four → same wing → PROVEN
- **Failure case:** Chaotic crossing — T1 and T2 disagree. Contamination audit: none (independent methods). Vortex audit: convergence at step 2 of 5 → depth 0.4 → VORTEX FLAG → WARN not PROVEN.

### BM-03 Retrodiction
- Each flow algorithm is one trajectory
- Interior points: D8, D∞, MFD, curvature all agree → PROVEN
- Boundary points: D8 → watershed A, D∞ → watershed B → WARN
- Flat area: all algorithms produce NAUGHT (no flow direction determinable) → FAIL (permanent NAUGHT)
- **Failure case documented:** Flat area never exits NAUGHT state. Correctly FAIL.

### BM-04 Retrodiction
- Core community nodes: Louvain, spectral, label propagation all agree → PROVEN
- Bridge nodes: 3 algorithms disagree → contamination check (none found) → low density WARN
- **Failure case:** Two algorithms assign bridge node to community A, two to B → TIE state → WARN with explicit tie record

### BM-05 Retrodiction
- Committed agents: 4/5 signals agree on regime → PROVEN
- Swing agents: 2 signals A, 2 signals B → TIE → WARN
- **Failure case:** Random shock trajectory creates false convergence. Anti-vortex check: shock signal converges at step 1 of 5 → depth 0.2 → VORTEX FLAG → trajectory excluded from basin count

---

## PART 6 — SPEC TIGHTENING (post-benchmark)

### Changes from v0.1 baseline

None yet — this is the initial iteration.

### Open spec gaps identified from benchmarks

1. **TIE state missing from schema:** BM-04 and BM-05 require explicit TIE handling when equal trajectories point to competing basins.
2. **Trajectory exclusion rule needed:** BM-05 identifies vortex trajectory (random shock) — need formal rule for excluding a trajectory from basin count when it fails anti-vortex check.
3. **NAUGHT permanence in flat areas:** BM-03 confirms that NAUGHT regions cannot be forced into signal. Needs explicit rule: if ≥50% of trajectories return NAUGHT at a point, the point is classified NAUGHT not WARN.

### Next-iteration plan (3 items)

1. Add TIE state to schema and convergence rules
2. Add trajectory exclusion protocol (vortex-failed trajectories → excluded, not counted toward k)
3. Define NAUGHT permanence threshold (≥50% NAUGHT trajectories → point is NAUGHT)

---

## METRICS TABLE

| Benchmark | Expected Accuracy | Failure Mode | N/U Stable? | Retrodict Passes? |
|-----------|-----------------|--------------|-------------|-------------------|
| BM-01 Double-well | >95% interior | Near-transition → WARN | YES | YES |
| BM-02 Lorenz | >98% interior | Chaotic crossing → WARN/vortex | YES | YES |
| BM-03 Watershed | >90% interior, ~50% boundary | Flat area → NAUGHT | YES | YES |
| BM-04 Graph | >85% core, ~40% bridge | Bridge → WARN/TIE | YES | PARTIAL (TIE gap) |
| BM-05 Agent | >80% committed | Random shock → vortex exclusion | YES | YES |

---

## FAILURE AUDIT

| ID | Benchmark | What broke | Why | Fix / Bound |
|----|-----------|-----------|-----|-------------|
| FA-01 | BM-01 | Velocity trajectory ambiguous at transition | Velocity = 0 in both wells | Document as WARN; do not exclude; reduces k |
| FA-02 | BM-02 | Early convergence in chaotic crossing | Lorenz wing assignment at step 2 of 5 | Anti-vortex rule correctly flags; trajectory excluded |
| FA-03 | BM-03 | Flat DEM areas return no flow direction | Algorithmic ambiguity, not theory failure | NAUGHT permanence rule; classify point as NAUGHT |
| FA-04 | BM-04 | Bridge nodes split equally between communities | Equal cross-community edges | TIE state needed; currently falls through to WARN |
| FA-05 | BM-05 | Random shock creates spurious early convergence | Shock at step 1 of 5; depth = 0.2 | Anti-vortex catches correctly; excluded from k count |

---

*Spec v0.1 — internally consistent, all benchmarks defined, failure modes documented.*
*Next iteration triggered by: TIE state implementation + trajectory exclusion formalization.*
