# Psych‑Morton Tensor Model and Adaptive Structured Interviewing

## Executive summary

This document is a thesis‑style **formalization draft** for the Psych‑Morton methodology: a two‑layer system that (a) **quantizes and locates** a person’s psychological state in a discrete, multi‑axis space and (b) uses an **adaptive, structured, information‑seeking interview pipeline** to reduce “surface‑only” therapy drift and concentrate clinician time on **high‑diagnostic‑value** observations. The approach is aligned with modern pushes toward **dimensional, transdiagnostic measurement** rather than purely categorical diagnosis (e.g., HiTOP; RDoC). citeturn0search0turn8search2turn8search3

The central methodological claim is not that a 7‑trait intake and adaptive interview “diagnoses” by itself, but that it can be engineered—with psychometrics, decision theory, and careful ethics—to generate: (i) **a reproducible state representation**, (ii) **a prioritized question path** that reduces unstructured-information dilution, and (iii) **a validation program** measuring reliability, validity (including incremental validity), and clinical utility.

Key empirical motivations (high level):

- **Unstructured interviewing** can reduce the diagnostic weight placed on truly diagnostic cues (dilution effects) and can underperform structured approaches in accuracy/reliability comparisons. citeturn4search3turn3search0turn3search2  
- **Mechanical/actuarial combination of data** is frequently comparable or superior to unaided clinical judgment in prediction tasks—supporting a “pipeline” that combines signals with explicit rules. citeturn4search0turn4search1  
- **Computerized adaptive testing (CAT)** and IRT frameworks show that you can reduce respondent burden while improving measurement precision by selecting the “next best” items. citeturn5search0turn0search6turn5search15  
- Dimensional frameworks (HiTOP; RDoC) explicitly support integrating multiple levels of information (self‑reports, behavior, circuits/biology) and organizing psychopathology dimensionally/hierarchically. citeturn0search0turn8search2turn10search14  

## Research problem and thesis contributions

### Problem statement

Weekly, mostly unstructured therapy sessions can unintentionally over‑allocate time to **well‑rehearsed narratives** and under‑sample the **latent drivers** (schemas, attribution styles, defensive strategies, interpersonal contingencies) that maintain distress and dysfunction. The methodological risk is classic: the more non‑diagnostic detail you collect without an explicit plan, the more you may **dilute** reliance on diagnostic information. citeturn4search3turn3search2

Meanwhile, psychiatry and clinical psychology face long‑standing measurement issues: categorical diagnoses can have inconsistent reliability in ordinary conditions, and dimensional alternatives have been proposed to reduce heterogeneity and comorbidity artifacts. citeturn10search0turn0search0turn19search15

### Proposed solution at a glance

The Psych‑Morton thesis is to build a **measurement‑driven, hypothesis‑testing** workflow:

- **Intake**: a 7‑trait instrument that produces a discrete trait vector (and a scalar “address” via Morton/Z‑ordering) suitable for longitudinal indexing and decision routing.
- **Adaptive interview**: a structured, safety‑bounded set of clinician prompts that is selected **conditionally** on current trait estimates to maximize expected information gain and reduce wasted session time.
- **Two‑layer linkage**: a design pathway to connect observational state to “substrate” measures (labs, imaging, digital phenotyping) consistent with RDoC‑style multi‑level models. citeturn8search2turn8search5turn8search0

### Contributions claimed in this draft

This draft formalizes contributions in four domains:

- **Psychometrics**: how to design the 7‑trait intake as a measurement instrument (reliability beyond alpha; DIF/measurement invariance; IRT/CAT capabilities). citeturn5search15turn13search6turn0search14  
- **Decision pipeline**: how to adaptively select question modules using CAT/IRT logic and evidence‑based assessment principles (likelihood ratios; incremental validity). citeturn5search0turn12search0turn12search2  
- **Computer science formalization**: how to treat the discrete multi‑trait space as a tensor and flatten it via locality‑preserving space‑filling curves (Morton/Z‑ordering), drawing on multidimensional indexing literature. citeturn6search0turn17search1turn6search1  
- **Ethics and safety boundaries**: how to replace the informal idea of “poke the narcissist” with an ethically bounded model of **structured probing** that protects alliance, autonomy, and risk management. citeturn15search0turn24search4turn23search1  

## Literature foundations and theoretical positioning

### Dimensional psychopathology and transdiagnostic measurement

The proposed approach fits naturally into **dimensional** models of psychopathology that aim to reduce categorical heterogeneity and leverage hierarchical structure (HiTOP). citeturn0search0turn8search3turn19search15 It also fits the RDoC emphasis on integrating multiple units of analysis—behavioral and biological—rather than relying on symptom checklists alone. citeturn8search2turn8search18turn8search14

Network approaches to psychopathology support the idea that symptoms and traits can interact dynamically, which motivates tracking **state trajectories** (not just static labels). citeturn0search13turn7search10

### Why structured + adaptive interviewing beats “casual sampling”

Evidence indicates structured interviews can outperform unstructured clinical interviewing in diagnostic accuracy/reliability comparisons in inpatient settings, and broader judgment/decision research warns that unstructured interviews expose interviewers to large amounts of nondiagnostic information that can dilute the impact of valid cues. citeturn3search0turn3search2turn4search3

Separately, the clinical vs actuarial literature shows formal/statistical combination often matches or exceeds clinical judgment. citeturn4search1turn4search0 This justifies building a pipeline that uses explicit combination rules and **auditable** decision routing.

### Measurement science and “hidden traits”

If the goal is to detect traits that are actively concealed or distorted (social desirability, impression management, self‑deception), the assessment must explicitly model that risk. Foundational work separates **self‑deception** from **impression management** (two‑component models) and provides instruments/approaches for measuring socially desirable responding. citeturn11search6turn11search12turn11search5

For a 7‑trait intake spanning affect/interpersonal/impulsivity/psychosis‑like experience domains, there are mature measures and dimensional models:

- Affect structure: circumplex models and valence‑core affect perspectives. citeturn7search0turn7search5  
- Brief affect measures: PANAS. citeturn1search3turn1search11  
- Self‑concealment/disclosure: Self‑Concealment Scale. citeturn2search0turn2search12  
- Narcissism: NPI (nonclinical trait) and PNI (grandiose + vulnerable presentations). citeturn1search12turn1search5  
- Impulsivity facets: UPPS model and urgency framework; BIS‑11 factor evidence. citeturn18search0turn18search5turn18search14  
- Psychosis‑like experiences: CAPE dimensions; schizotypal traits (SPQ); screening instruments like PQ‑B (research context). citeturn19search1turn19search4turn19search2  

### Multi‑level linkage and computational psychiatry

Computational psychiatry explicitly frames the translation problem: mapping between complex behavioral data and neurobiological mechanisms, with emphasis on formal models and rigor. citeturn8search0turn8search4 Digital phenotyping and measurement‑based care literature motivates higher‑frequency, ecologically valid measurements rather than relying solely on periodic clinician impressions. citeturn8search5turn9search5turn9search0

## Model formalization as a tensor algebra with Morton indexing

### Existing framework checklist from your SSOT draft

From your SSOT draft (Psych‑Morton Algebra — SSOT, 2026‑04‑07), the current canonical components are:

1. A discrete **observational layer** mapping phenomenological/behavioral state to a scalar address via a Morton (Z‑order) curve.  
2. Three axes, each k‑bit integer (k=3 currently): X=Valence, Y=Visibility, Z=Density; total state space 8³=512.  
3. A scalar Morton address **M** computed by bit‑interleaving (Z, Y, X order).  
4. A dynamic governor model S(t)=M·sin(vt+φ) and a medication coefficient C scaling v.  
5. A “gap” or residual term N = |S_observed − S_calculated| as the clinical target (bridge between observed state and substrate‑predicted state).  

This thesis draft preserves those as the “seed” and extends them to seven axes and to an adaptive interview system.

### Why a tensor model is a natural extension

A discrete multi‑trait psychological state can be represented as either:

- A **vector** in ℤᵈ (d traits), or  
- A **d‑way tensor index** (a coordinate into a discrete d‑dimensional grid).

In applied math/psychometrics, multiway/tensor models have a long history (three‑mode factor analysis; tensor decompositions). citeturn16search1turn16search0 This supports describing the 7‑trait state space as a rank‑7 tensor grid while retaining standard multivariate methods for estimation/validation.

### Formal definition of the seven‑trait state space

Let:

- d = 7 traits.  
- k = bit depth per trait (k=3 in your current SSOT for 8 levels; extension keeps this as a first implementation).  
- Trait coordinates are integers:  
  \[
  \mathbf{T} = (T_0,\dots,T_{d-1}),\quad T_j \in \{0,\dots,2^k-1\}.
  \]

The **state space** is the discrete hypercube:
\[
\Omega = \{0,\dots,2^k-1\}^d,
\]
with size \(|\Omega| = (2^k)^d\). For k=3 and d=7, \(|\Omega| = 8^7 = 2{,}097{,}152\) states (large but indexable).

### Morton address for d traits

Write each trait in binary with bits \(t_{j,i}\in\{0,1\}\) where i indexes bit position (0 = least significant):

\[
T_j = \sum_{i=0}^{k-1} t_{j,i}\,2^i.
\]

Define an interleaving order (a design choice). For seven traits, choose an order that reflects which dimensions should produce “larger jumps” when they change (your SSOT makes Z most significant; this generalizes by putting the most clinically destabilizing axes earliest in the interleave). This “bit significance engineering” is conceptually similar to how multidimensional indexes use bit‑interleaving to linearize space. citeturn6search0turn17search1turn6search1

One canonical d‑dimensional Morton code is:
\[
M(\mathbf{T})=\sum_{i=0}^{k-1}\sum_{j=0}^{d-1} t_{j,i}\,2^{di+j}.
\]

This is the **tensor‑flattening operator**: it maps a d‑way coordinate into a single scalar key while partially preserving locality (nearby points tend to map nearby). The database literature uses Z‑order/Morton keys specifically for this locality‑preserving linearization and then applies 1D index structures (trees, B‑trees, etc.). citeturn6search0turn17search1turn6search1

### Locality, indexing, and why this is not arbitrary

Space‑filling curves (Z‑order/Morton; Hilbert) are used for multidimensional indexing because they allow multidimensional data to be stored with 1D index structures while retaining useful locality properties. citeturn6search1turn17search6turn17search1 Canonical spatial indexing structures (e.g., R‑trees) exist too; Z‑order approaches are one explicit alternative with different tradeoffs. citeturn17search0

This matters clinically because it creates a coherent interpretation of “state neighborhoods,” “jumps,” and “trajectories” in a way compatible with dynamical models of affect and nonlinear change in psychotherapy. citeturn7search6turn7search19

### Closure, operations, and metrics

A “closed algebra” requires the operations you perform on states to map back into the allowable state space.

A practical minimal set:

- **Decode/encode**: invertible mapping between \(\mathbf{T}\) and \(M\).  
- **Distance metric**: define clinically meaningful distance in trait space (not necessarily scalar distance in M).  
- **State composition**: combine states (e.g., baseline vs observed; clinician vs self‑report) to produce a valid state.  
- **Update operator**: define how interventions and time move the state.

Suggested formal choices, justified by psychometrics and indexing literature:

- Use a **trait‑space distance** such as Manhattan (L1) to preserve consistent interpretation of one‑unit changes across the cube, rather than relying on raw scalar differences in M (because the curve is non‑linear in space). This aligns with the measurement principle that interpretability belongs to the underlying dimensions, not to an arbitrary linearization. citeturn13search1turn12search0  
- Use a **project‑back** operator for closure: if an operation yields a real‑valued vector, round/clip per dimension to [0, 2^k−1] and re‑encode. This is an explicit mathematical version of keeping operations inside \(\Omega\).

## Methodology for the seven‑trait intake and the adaptive interview pipeline

### The seven traits as measurable constructs

Below is a **research‑defensible** 7‑axis proposal that preserves your original three constructs and adds four axes grounded in major measurement literatures. The specific axis names are editable; what matters is that each axis maps onto validated constructs with established measures.

| Axis | Construct target | Why it belongs in a “high diagnostic value” intake | Example validated measurement families |
|---|---|---|---|
| Valence | Positive/negative affect & prosocial–antagonistic tone | Core building block of emotion; transdiagnostic relevance citeturn7search0turn7search5 | PANAS; affect circumplex measures citeturn1search3turn7search0 |
| Visibility | Disclosure vs concealment / surface presentation | Directly targets “hidden traits” and impression management citeturn2search0turn11search6 | Self‑Concealment Scale; disclosure measures citeturn2search0turn2search1 |
| Density | Externalization vs self‑centric attribution / narcissistic organization | Linked to locus of control + narcissism constructs citeturn1search10turn1search5 | Rotter LoC; NPI/PNI citeturn1search10turn1search12turn1search5 |
| Arousal | Activation/energy (risk for oscillation, agitation, inertia) | Affective dynamics matter clinically; mood instability is measurable citeturn7search6turn9search2 | EMA/ESM approaches; activation scales citeturn9search0turn7search6 |
| Affiliation | Warmth/connectedness vs detachment | Anchored in interpersonal circumplex traditions citeturn2search7turn2search6 | Interpersonal circumplex instruments citeturn2search7turn18search7 |
| Dominance | Agency/control vs submissiveness | Captures interpersonal style and conflict patterns citeturn2search7turn18search7 | Interpersonal Adjective Scales family citeturn18search7 |
| Control | Impulsivity vs restraint/executive control | Strong transdiagnostic predictive relevance citeturn18search0turn18search14 | UPPS/urgency; BIS‑11 citeturn18search0turn18search5turn18search14 |

This is one defensible configuration. A second defensible configuration is to replace one interpersonal axis with a **reality‑anchoring / psychoticism‑proneness** axis (SPQ/CAPE/PQ‑B) if your target population emphasizes psychosis‑spectrum phenomena; those measures have established dimensional evidence. citeturn19search1turn19search4turn19search2

### Operationalizing k=3 discretization without pretending it is “natural”

A k=3 discretization (0–7) is an **engineering decision**, not a claim that the human psyche naturally has 8 bins. Two principles keep this scientifically honest:

- Treat raw scores as continuous, estimate latent traits (IRT/SEM), then discretize for indexing and routing. citeturn5search0turn22search8turn22search1  
- Calibrate the discretization against norms and invariance testing, because cutpoints can drift by population and context. citeturn0search14turn12search0

A defensible mapping procedure:

1. Collect continuous scale scores for each axis using short forms and/or CAT. citeturn5search0turn0search6  
2. Transform to a latent estimate (θ) per dimension with known standard error (IRT). citeturn5search0turn22search8  
3. Convert θ to bins using empirically derived thresholds (e.g., octiles on a reference population, or clinically meaningful cutpoints if validated).  
4. Store both: the discretized \(T_j\) for routing + the continuous θ and SE for scientific analysis.

### The adaptive “directed questionnaire” pipeline

This section replaces the informal “poke the narcissist” framing with an evidence‑aligned concept:

- The pipeline is **structured probing + hypothesis testing**, where the clinician selects prompts to discriminate among competing hypotheses with minimal harm, while preserving therapeutic alliance and informed consent. Ethical standards emphasize beneficence/nonmaleficence, integrity, and respect for rights/dignity—so the probing must be non‑coercive and transparently justified. citeturn15search0turn15search2turn15search1  
- Alliance research shows that alliance quality reliably relates to outcome; rupture/repair frameworks explicitly teach how to manage strain if probing triggers defensiveness. citeturn24search4turn23search1turn9search15  

#### Pipeline design goals

The pipeline should optimize four measurable targets:

- **Information gain**: reduce posterior uncertainty about latent axes or “case formulation” hypotheses (CAT/IRT logic). citeturn5search0turn0search6  
- **Diagnostic efficiency**: maximize likelihood ratios / discriminative accuracy for the hypotheses you actually care about. citeturn12search2turn12search14  
- **Incremental validity**: show that the directed interview adds predictive value beyond intake alone. citeturn12search0turn4search0  
- **Safety/alliance stability**: monitor rupture markers and avoid destabilizing provocation as a “technique.” citeturn23search1turn15search0  

#### Concrete module architecture

Think of the interview as a set of modules; each module is a bank of items/prompts with known measurement properties.

Example modules (illustrative):

- Attribution & responsibility (externalization vs internalization): rooted in locus of control frameworks. citeturn1search10  
- Narcissism style: grandiose vs vulnerable patterns (PNI supports this dimensional split). citeturn1search5  
- Concealment & disclosure: self‑concealment and impression management. citeturn2search0turn11search6  
- Impulsivity under emotion (urgency): mood‑based rash action. citeturn18search5  
- Interpersonal conflicts (dominance/affiliation): circumplex‑based prompts. citeturn2search7turn2search6  
- Mood dynamics and context (EMA‑informed): concentrate on variability rather than static “how is your week.” citeturn9search0turn9search2  

#### Selection rule: “next best question” (CAT logic)

A prototypical selection rule:

- Maintain a current estimate of latent traits θ and an uncertainty estimate (SE or posterior variance).  
- Each candidate item has an information function (IRT).  
- Select the item that maximizes expected information subject to constraints (no high‑risk content unless safety criteria satisfied; no repeated alliance strain; time budget).

This strategy is directly supported in modern CAT applications that achieve high correlations with long tests using a small number of adaptively selected items, improving efficiency and precision. citeturn5search0turn5search4turn0search6

#### Workflow diagram

```mermaid
flowchart TD
  A[Intake: 7-trait scores + validity checks] --> B[Latent trait estimation (IRT/SEM)]
  B --> C[Discretize to k-bit bins for indexing]
  C --> D[Morton encode -> scalar address M]
  B --> E[Adaptive interview controller]
  E --> F{Safety & ethics gate}
  F -->|OK| G[Next module + item selection (max info gain)]
  F -->|Not OK| H[Stabilization / alliance repair + defer probing]
  G --> I[Session data: responses + clinician observation]
  I --> J[Update trait estimates + uncertainty]
  J --> E
  I --> K[Longitudinal store: (time, T, M, SE, notes)]
```

## Validation, implementation plan, timelines, and deliverables

### Validation plan aligned with evidence‑based assessment principles

Validation must go beyond impressive narratives. A publishable program should include:

- **Reliability**: internal consistency using omega (not only alpha), composite reliability for congeneric measures, and test‑retest / interrater where relevant. citeturn5search15turn13search6turn3search16  
- **Construct validity**: convergent/discriminant patterns against established scales (e.g., narcissism, self‑concealment, impulsivity). citeturn1search5turn2search0turn18search0  
- **Measurement invariance / DIF**: examine whether items behave consistently across groups and contexts (PROMIS DIF work is an existence proof for this kind of testing). citeturn0search14turn0search2  
- **Predictive + incremental validity**: evaluate whether the adaptive interview improves prediction of outcomes (symptom change, functional outcomes, relapse markers) beyond intake, consistent with evidence‑based assessment emphasis on incremental validity. citeturn12search0turn4search0  
- **Clinical utility and feasibility**: measure clinician burden and acceptability; structured methods may increase reliability but can have mixed “utility” impressions in naturalistic contexts—so this must be tested, not assumed. citeturn3search19turn3search3  
- **Reporting standards**: for observational data, plan STROBE‑aligned reporting. citeturn15search3turn15search19  

### Implementation stack suggestions

A rigorous build benefits from standard, citable tools:

- **IRT/CAT**: R package *mirt* (multidimensional IRT), plus CAT logic. citeturn22search8turn22search0  
- **SEM / factor validation**: *lavaan*. citeturn22search1turn22search17  
- **Classifier evaluation**: ROC/AUC tooling such as *pROC*. citeturn22search6turn22search2  
- **Citations & writing**: Zotero for reference management (product), and an academic writing workflow (e.g., LaTeX/Overleaf) for reproducibility; Zotero is widely used as a research assistant tool. citeturn22search7  

### Timelines and effort options

Effort depends strongly on whether you’re producing:

- a thesis **draft manuscript + designed instruments** (theoretical), or  
- a thesis **with pilot data** (empirical), or  
- a thesis **with validation studies** (full psychometrics).

Below are three viable scopes. Hours are estimates for a single primary author with normal academic constraints; they assume writing plus managing sources and figures.

| Scope option | Estimated effort | Deliverables | What is “done” |
|---|---:|---|---|
| Quick | 25–40 hours | Thesis proposal + literature review skeleton + 7‑trait draft items + pipeline spec + reference library (≥50 sources) | Defensible conceptual thesis draft ready for committee feedback |
| Standard | 80–140 hours | Full thesis‑style draft (Intro/Lit/Methods/Model/Ethics) + simulated data demo + interview module banks v1 + preregistration draft | Manuscript that can be submitted as a theoretical/methods paper; ready for IRB planning |
| Thorough | 250–450 hours | Pilot study (N≈50–150) + reliability/IRT analyses + feasibility metrics + revised instrument v2 + reproducible code + STROBE‑ready reporting | Empirical thesis with validation results and publishable tables/figures |

Mermaid timeline (illustrative for the “standard” option):

```mermaid
gantt
  title Psych‑Morton thesis build (standard scope) — illustrative timeline
  dateFormat  YYYY-MM-DD
  axisFormat  %b %d
  section Design
  Trait definitions & mapping decisions        :a1, 2026-04-08, 10d
  Item writing + expert review                :a2, after a1, 14d
  section Measurement
  Pilot calibration plan + preregistration    :b1, after a2, 10d
  IRT/SEM simulation + power/precision checks :b2, after b1, 14d
  section Pipeline
  Adaptive routing rules + safety gates       :c1, after a2, 14d
  Module bank authoring + clinician scripts   :c2, after c1, 21d
  section Thesis writing
  Literature review integration               :d1, 2026-04-08, 35d
  Methods + model formalization chapters      :d2, after d1, 28d
  Ethics + limitations + future work          :d3, after d2, 10d
  Final assembly + formatting                 :d4, after d3, 10d
```

### Ethics and safety requirements (non‑negotiable)

Because this system touches mental health assessment and could be used clinically, it must be built under ethics principles that explicitly prohibit harm and coercion.

Concrete requirements:

- **Explicit consent** for structured probing and for any data linkage beyond standard care. citeturn15search2  
- **Nonmaleficence**: the system must not operationalize “provocation” as a technique; instead it must operationalize “structured inquiry” with monitoring and an option to de‑escalate and repair alliance strain. citeturn15search0turn23search1  
- **Assessment standards**: adhere to professional guidance on assessment and privacy norms (APA ethics code includes standards relevant to assessment practice). citeturn15search0turn15search4  

## References

Below is a curated cross‑domain list (≥50) of reputable sources suitable for an academic thesis. All are non‑Wikipedia.

### Psychological measurement, dimensional psychopathology, and decision science

Kotov, R., et al. “The Hierarchical Taxonomy of Psychopathology (HiTOP).” *Journal of Abnormal Psychology* (2017). citeturn0search0turn0search12  

Cicero, D. C., et al. “State of the Science: The Hierarchical Taxonomy of Psychopathology (HiTOP).” *Behavior Therapy* (2024). citeturn8search3turn8search7  

Borsboom, D., & Cramer, A. O. J. “Network analysis: an integrative approach to the structure of psychopathology.” *Annual Review of Clinical Psychology* (2013). citeturn0search13turn0search9  

Krueger, R. F., & Markon, K. E. “Reinterpreting comorbidity: a model‑based approach…” *Annual Review of Clinical Psychology* (2006). citeturn19search15turn19search19  

Regier, D. A., et al. “DSM‑5 Field Trials… Test‑Retest Reliability…” *American Journal of Psychiatry* (2013). citeturn10search0turn10search8  

Kraemer, H. C., et al. “DSM‑5: How Reliable Is Reliable Enough?” *American Journal of Psychiatry* (2012). citeturn10search1turn10search9  

Widiger, T. A., & Trull, T. J. “Plate tectonics… Shifting to a dimensional model.” *American Psychologist* (2007). citeturn10search14turn10search2  

Krueger, R. F., Derringer, J., Markon, K. E., Watson, D., & Skodol, A. E. “Initial construction… trait model and inventory for DSM‑5.” *Psychological Medicine* (2012). citeturn20search0turn20search8  

Hunsley, J., & Mash, E. J. “Evidence‑based assessment.” *Annual Review of Clinical Psychology* (2007). citeturn12search0turn12search12  

Grove, W. M., et al. “Clinical versus mechanical prediction: a meta‑analysis.” *Psychological Assessment* (2000). citeturn4search0turn4search4  

Dawes, R. M., Faust, D., & Meehl, P. E. “Clinical versus actuarial judgment.” *Science* (1989). citeturn4search13turn4search9  

Nisbett, R. E., Zukier, H., & Lemley, R. E. “The dilution effect: Nondiagnostic information…” *Cognitive Psychology* (1981). citeturn4search3turn4search7  

Dana, J., et al. “Belief in the unstructured interview: The persistence of an illusion.” *Judgment and Decision Making* (2022). citeturn3search2turn3search9  

Wilkinson, L., & APA Task Force on Statistical Inference. “Statistical Methods in Psychology Journals…” *American Psychologist* (1999). citeturn21search6turn13search15  

Cohen, J. “The Earth Is Round (p < .05).” *American Psychologist* (1994). citeturn24search3turn24search15  

Benjamini, Y., & Hochberg, Y. “Controlling the False Discovery Rate…” *Journal of the Royal Statistical Society B* (1995). citeturn21search1turn21search5  

Stevens, S. S. “On the Theory of Scales of Measurement.” *Science* (1946). citeturn13search1turn13search5  

Velleman, P. F., & Wilkinson, L. “Nominal, Ordinal, Interval, and Ratio Typologies Are Misleading.” *The American Statistician* (1993). citeturn13search3  

Raykov, T. “Estimation of Composite Reliability for Congeneric Measures.” *Applied Psychological Measurement* (1997). citeturn13search6turn13search2  

### Affect, emotion dynamics, and experience sampling

Russell, J. A. “A circumplex model of affect.” *Journal of Personality and Social Psychology* (1980). citeturn7search0turn7search8  

Watson, D., Clark, L. A., & Tellegen, A. “Development and validation… PANAS.” *Journal of Personality and Social Psychology* (1988). citeturn1search3turn1search11  

Barrett, L. F. “Valence is a basic building block of emotional life.” *Journal of Research in Personality* (2006). citeturn7search1turn7search5  

Kuppens, P., Oravecz, Z., & Tuerlinckx, F. “Feelings Change… temporal dynamics of affect.” *Journal of Personality and Social Psychology* (2010). citeturn7search6  

Shiffman, S., Stone, A. A., & Hufford, M. R. “Ecological Momentary Assessment.” *Annual Review of Clinical Psychology* (2008). citeturn9search0turn9search8  

aan het Rot, M., et al. “Mood disorders in everyday life: A systematic review of experience sampling…” *Clinical Psychology Review* (2012). citeturn9search2  

### Visibility, concealment, and response distortion

Larson, D. G., & Chastain, R. L. “Self‑concealment: conceptualization, measurement, and health implications.” *Journal of Social and Clinical Psychology* (1990). citeturn2search0turn2search16  

Paulhus, D. L. “Two‑component models of socially desirable responding…” (Self‑Deception and Impression Management). *Journal of Personality and Social Psychology* (1984). citeturn11search6turn11search2  

Paulhus, D. L., & Reid, D. B. “Enhancement and denial in socially desirable responding.” *Journal of Personality and Social Psychology* (1991). citeturn11search12  

Crowne, D. P., & Marlowe, D. “A new scale of social desirability independent of psychopathology.” *Journal of Consulting Psychology* (1960). citeturn11search5  

### Narcissism, locus of control, impulsivity, psychosis‑like experiences

Rotter, J. B. “Generalized expectancies for internal versus external control of reinforcement.” *Psychological Monographs* (1966). citeturn1search10turn1search2  

Raskin, R., & Terry, H. “A principal‑components analysis of the Narcissistic Personality Inventory…” *Journal of Personality and Social Psychology* (1988). citeturn1search12turn1search8  

Pincus, A. L., et al. “Initial construction and validation of the Pathological Narcissism Inventory.” (2009). citeturn1search5turn1search1  

Whiteside, S. P., & Lynam, D. R. “The Five Factor Model and impulsivity…” *Personality and Individual Differences* (2001). citeturn18search0turn18search12  

Cyders, M. A., & Smith, G. T. “Mood‑based rash action and its components: positive and negative urgency.” *Personality and Individual Differences* (2007). citeturn18search5  

Patton, J. H., Stanford, M. S., & Barratt, E. S. “Factor structure of the Barratt Impulsiveness Scale (BIS‑11).” *Journal of Clinical Psychology* (1995). citeturn18search14turn18search2  

Raine, A. “The SPQ: A scale for the assessment of schizotypal personality…” *Schizophrenia Bulletin* (1991). citeturn19search4turn19search8  

Stefanis, N. C., et al. “Evidence that three dimensions of psychosis have a distribution in the general population.” *Psychological Medicine* (2002). citeturn19search1turn19search13  

Loewy, R. L., et al. “Psychosis risk screening with the Prodromal Questionnaire—Brief (PQ‑B).” *Schizophrenia Research* (2011). citeturn19search2turn19search10  

### Structured interviewing, alliance, and safety

Miller, P. R., et al. “Inpatient diagnostic assessments: Accuracy of structured vs unstructured interviews.” *Psychiatry Research* (2001). citeturn3search0turn23search0  

Segal, D. L. “Structured versus Semistructured versus Unstructured Interviews.” (Reference entry). citeturn3search11  

Horvath, A. O., & Symonds, B. D. “Relation between working alliance and outcome in psychotherapy: a meta‑analysis.” *Journal of Counseling Psychology* (1991). citeturn24search4  

Safran, J. D., & Muran, J. C. (chapter materials) “Negotiating the therapeutic alliance … rupture/repair frameworks.” (2000). citeturn23search1turn9search15  

APA. *Ethical Principles of Psychologists and Code of Conduct (2017).* citeturn15search0turn15search4  

HHS. *The Belmont Report* (Respect for persons, beneficence, justice). citeturn15search2turn15search6  

### IRT, CAT, and instrument evaluation

Gibbons, R. D., et al. “Development of a computerized adaptive test for depression (CAT‑DI).” *JAMA Psychiatry* (2012). citeturn5search0turn5search8  

Blomqvist, I., et al. “Psychometric properties… PROMIS item banks… IRT and CAT…” *Quality of Life Research* (2025). citeturn0search2  

Chalmers, R. P. “mirt: A Multidimensional Item Response Theory Package for the R Environment.” *Journal of Statistical Software* (2012). citeturn22search8turn22search0  

Rosseel, Y. “lavaan: An R Package for Structural Equation Modeling.” *Journal of Statistical Software* (2012). citeturn22search1turn22search17  

Robin, X., et al. “pROC: an open‑source package for R and S+ to analyze and compare ROC curves.” *BMC Bioinformatics* (2011). citeturn22search6turn22search2  

Dunn, T. J., Baguley, T., & Brunsden, V. “From alpha to omega…” *British Journal of Psychology* (2014). citeturn5search15turn5search3  

Revelle, W., & Zinbarg, R. E. “Coefficients Alpha, Beta, Omega, and the glb…” *Psychometrika* (2009). citeturn5search6turn5search2  

### Computational psychiatry and multi‑level linkage

Huys, Q. J. M., Maia, T. V., & Frank, M. J. “Computational psychiatry as a bridge…” *Nature Neuroscience* (2016). citeturn8search0turn8search12  

Insel, T. R. “Digital Phenotyping Technology for a New Science of Behavior.” *JAMA* (2017 viewpoint). citeturn8search5turn8search9  

NIMH. “Research Domain Criteria (RDoC)” (framework description). citeturn8search2  

### Neurobiology examples for a potential “substrate layer” (optional but relevant)

Howes, O. D., & Kapur, S. “Dopamine hypothesis of schizophrenia: Version III…” *Schizophrenia Bulletin* (2009). citeturn25search0turn25search4  

Coyle, J. T. “Glutamate and schizophrenia: beyond the dopamine hypothesis.” *Cellular and Molecular Neurobiology* (2006). citeturn25search1turn25search13  

Meltzer, H. Y. “The role of serotonin in antipsychotic drug action.” (review context). citeturn25search14turn25search6  

Buckner, R. L., Andrews‑Hanna, J., & Schacter, D. “The brain’s default network…” *Annals of the NY Academy of Sciences* (2008). citeturn25search3turn25search7  

### Tensor modeling and multidimensional indexing

Tucker, L. R. “Some mathematical notes on three‑mode factor analysis.” *Psychometrika* (1966). citeturn16search1turn16search5  

Kolda, T. G., & Bader, B. W. “Tensor decompositions and applications.” *SIAM Review* (2009). citeturn16search0turn16search4  

Morton, G. M. “A computer oriented geodetic data base; and a new technique in file sequencing.” (1966). citeturn6search0turn6search8  

Tropf, H., & Herzog, H. “Multidimensional range search in dynamically balanced trees.” (1981). citeturn17search1turn17search8  

Bayer, R. “The universal B‑tree for multidimensional indexing: general concepts.” (1996). citeturn6search1turn6search9  

Guttman, A. “R‑trees: A dynamic index structure for spatial searching.” (1984). citeturn17search0turn17search14  

Lawder, J. K., & King, P. J. H. “Querying multi‑dimensional data indexed using the Hilbert space‑filling curve.” *SIGMOD Record* (2001). citeturn17search6turn17search2  

Butz, A. R. “Alternative algorithm for Hilbert’s space‑filling curve.” *IEEE Transactions on Computers* (1971). citeturn17search13turn6search14